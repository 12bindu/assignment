# Passing Arguments
'''
1. Positional arguments (Required arguments)
2. Default arguments
3. Keyword arguments(Named arguments)
'''
100
x = 10

# 1. Positional arguments (Required arguments)
print("--------1. Positional arguments--------------")

