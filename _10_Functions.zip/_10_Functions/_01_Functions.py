'''
builtins.py
'''

'''
print() id() type() 

Numbers : int() float() complex()
Boolean : bool()
String  : str()
List    : list()
Tuple   : tuple()
Dict    : dict()
Set     : set()

Collections: DefaultDict OrderedDict 
             NamedTuple
             FrozenSet
             Counter
             


'''