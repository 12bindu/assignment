x = 10
e_id = 100
e_name = 'Madhu'

def get_data():
    return 'Hello World'